-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: S11P12C107
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `invitation`
--

DROP TABLE IF EXISTS `invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitation` (
  `invitation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studio_id` int(10) unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` text COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`invitation_id`),
  KEY `FK_INVITATION` (`studio_id`),
  CONSTRAINT `FK_INVITATION` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_studio_TO_invitation_1` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitation`
--

LOCK TABLES `invitation` WRITE;
/*!40000 ALTER TABLE `invitation` DISABLE KEYS */;
INSERT INTO `invitation` VALUES (61,262,'SF 소설 쓰실 분 모십니다.','ㄱㄱ'),(62,263,'미스터리 스릴러 쓰실 팀원 모십니다','ㅁ'),(63,264,'가족영화 각본 쓰실분 모십니다','ㄱ'),(64,265,'퓨전 소설 쓰실분~','ㄱㄱ'),(65,266,'현대 퓨전 판타지 쓰실 분 구해요','ㄱㄱ'),(66,267,'퓨전 소설 쓰실분~','안녕하세요,\n\n저는 현재 유명한 탐정 사무소라는 제목의 추리, 모험 소설을 집필 중인 작가입니다. 이 소설은 독자들을 사로잡는 흥미진진한 미스터리와 스릴 넘치는 모험을 중심으로 한 작품입니다. 이미 탄탄한 기획과 플롯이 마련되어 있으며, 함께 이 작품을 완성해 주실 소설가를 찾고 있습니다.\n\n모집 대상:\n\n경력: 3년 이상의 소설 집필 경험이 있는 분\n장르: 추리, 미스터리, 모험 장르에 익숙하신 분\n스타일: 독창적이고 몰입감 있는 문체를 구사하시는 분\n협업: 공동 집필 및 소통에 능숙하신 분\n작업 내용:\n\n기획된 스토리에 따라 함께 소설의 전개를 구성하고, 각 챕터의 집필 및 수정을 담당하게 됩니다.\n주요 등장인물의 심리와 행동을 생동감 있게 묘사하여 독자들이 작품 속으로 깊이 빠져들 수 있도록 할 것입니다.\n우대 사항:\n\n기존에 출간된 작품이나 연재 경험이 있으신 분\n스토리텔링 능력과 논리적인 플롯 구성에 자신이 있으신 분\n지원 방법:\n자신의 포트폴리오와 간략한 자기소개를 첨부하여 지원해 주세요. 선발된 분과는 세부적인 작업 일정 및 조건을 협의할 예정입니다.\n\n유명한 탐정 사무소의 스토리를 함께 만들어갈 열정 넘치는 작가님의 지원을 기다립니다!'),(67,261,'유명한 탐정 사무소 집필 팀원 모집합니다','안녕하세요,\n\n저는 현재 유명한 탐정 사무소라는 제목의 추리, 모험 소설을 집필 중인 작가입니다. \n이 소설은 독자들을 사로잡는 흥미진진한 미스터리와 스릴 넘치는 모험을 중심으로 한 작품입니다. \n이미 탄탄한 기획과 플롯이 마련되어 있으며, 함께 이 작품을 완성해 주실 소설가를 찾고 있습니다.\n\n모집 대상:\n경력: 3년 이상의 소설 집필 경험이 있는 분\n장르: 추리, 미스터리, 모험 장르에 익숙하신 분\n스타일: 독창적이고 몰입감 있는 문체를 구사하시는 분\n협업: 공동 집필 및 소통에 능숙하신 분\n\n작업 내용:\n기획된 스토리에 따라 함께 소설의 전개를 구성하고, 각 챕터의 집필 및 수정을 담당하게 됩니다.\n주요 등장인물의 심리와 행동을 생동감 있게 묘사하여 독자들이 작품 속으로 깊이 빠져들 수 있도록 할 것입니다.\n\n우대 사항:\n기존에 출간된 작품이나 연재 경험이 있으신 분\n스토리텔링 능력과 논리적인 플롯 구성에 자신이 있으신 분\n\n유명한 탐정 사무소의 스토리를 함께 만들어갈 열정 넘치는 작가님의 지원을 기다립니다!'),(70,277,'이 세상의 각종 미스터리에 관심있으신분','미스테리 글 같이 쓸사람 모집합니다'),(71,281,'추리소설 같이 작업하실분 찾습니다!','같이 작업하실 작가분 구합니다');
/*!40000 ALTER TABLE `invitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitation_code`
--

DROP TABLE IF EXISTS `invitation_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitation_code` (
  `invitation_code_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studio_id` int(10) unsigned NOT NULL,
  `expiration_date` date DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`invitation_code_id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `unique_studio_id` (`studio_id`),
  CONSTRAINT `FK_INVITATION_CODE` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_studio_TO_invation_code_1` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitation_code`
--

LOCK TABLES `invitation_code` WRITE;
/*!40000 ALTER TABLE `invitation_code` DISABLE KEYS */;
INSERT INTO `invitation_code` VALUES (10,252,'2024-08-22','eyJhbGciOiJIUzI1NiJ9.eyJTdHVkaW9JZCI6MjUyLCJpYXQiOjE3MjM2OTY2MTYsImV4cCI6MTcyMzcyMTgxNn0.oNN-TQr4PUiOV5-lhUNpEb0qRzLGTf0kPJZ13GrWvK0'),(11,261,'2024-08-22','eyJhbGciOiJIUzI1NiJ9.eyJTdHVkaW9JZCI6MjYxLCJpYXQiOjE3MjM3MjI2OTEsImV4cCI6MTcyMzc0Nzg5MX0.CHGl_bBmfM2CvXArjANnvlnU8ZL83YR1f_5eA_k7UDM');
/*!40000 ALTER TABLE `invitation_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitation_tag`
--

DROP TABLE IF EXISTS `invitation_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitation_tag` (
  `invitation_tag_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) unsigned NOT NULL,
  `invitation_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`invitation_tag_id`),
  KEY `FK_tag_TO_invitation_tag_1` (`tag_id`),
  KEY `FK_invitation_TO_invitation_tag_1` (`invitation_id`),
  CONSTRAINT `FK_invitation_TO_invitation_tag_1` FOREIGN KEY (`invitation_id`) REFERENCES `invitation` (`invitation_id`),
  CONSTRAINT `FK_tag_TO_invitation_tag_1` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitation_tag`
--

LOCK TABLES `invitation_tag` WRITE;
/*!40000 ALTER TABLE `invitation_tag` DISABLE KEYS */;
INSERT INTO `invitation_tag` VALUES (90,5,61),(91,6,61),(92,7,62),(93,8,62),(94,21,63),(95,23,63),(96,24,63),(97,3,64),(98,4,64),(99,3,65),(100,5,65),(101,10,65),(102,3,66),(103,5,66),(104,10,66),(105,7,67),(106,8,67),(107,15,67),(113,6,70),(114,7,70),(115,8,71),(116,12,71);
/*!40000 ALTER TABLE `invitation_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile` (
  `profile_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `pen_name` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `introduction` text COLLATE utf8mb4_bin NOT NULL,
  `image_url` varchar(2083) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`profile_id`),
  KEY `FK_user_TO_profile_1` (`user_id`),
  CONSTRAINT `FK_user_TO_profile_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (212,227,'박싸피','ㅁㄴㅇㄻㄴㅇㄹ','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/0cc76a98-8a77-49f2-a950-f1e73ed3fca2%25default_profile.png'),(213,228,'익명의 작가_cd44a605-3959-e394-37d6-a6afdba9fd80','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/3ca13e8c-70e8-4fbb-b9d5-88ca7470a374%25default_profile.png'),(214,229,'김연지','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/0a6eb8f9-28ce-45dc-951a-055921d07e03%25default_profile.png'),(215,230,'익명의 작가_96668b8b-e414-92f6-c369-82b76378374c','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/9198af00-55bc-45ca-a37e-cba03d45bcf1%25default_profile.png'),(216,231,'김시온','아무것도 몰라요','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/7dc74ac3-5a10-4397-973e-cd1e996d70e4%25default_profile.png'),(217,232,'익명의 작가_7033c562-9b92-70a7-76d9-29b96816b30f','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/aea51af8-a519-41ce-b7c6-d94a90f8a71c%25default_profile.png'),(218,233,'이중현','싸피 11기 이중현','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/6051a3a1-07f3-4ca3-baa3-8000fa15f404%25%ED%95%A9%EA%B2%A9%EC%A6%9D%EB%AA%85.jpg'),(219,234,'익명의 작가_7e0ce028-c0cc-6241-f8be-9abcb6e99486','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/420b7235-9a8a-437a-9f7b-f0572b18fd06%25default_profile.png'),(220,235,'오늘의 소설','오늘의 소설을 작성합니다.','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/a8ddf6de-d803-49d0-abfc-b9672735a5f4%25default_profile.png'),(221,236,'익명의 작가_362c7f17-ff8c-bf21-4632-9abc4df283f6','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/2fb00bdb-ad4c-4453-9008-55ca5dee6274%25default_profile.png'),(222,237,'미스테리 극작가','미스테리 좋아요','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/06392cfb-a11c-403d-b05e-8dd4a6bfaae0%25image-removebg-preview.png'),(223,238,'싸피코치','코코치','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/b20e623c-662c-4b3c-9250-e89894c2bfd3%25default_profile.png'),(224,239,'익명의 작가_cb50daae-889a-eefb-049c-73eb5cf16a05','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/ba769ac9-0361-46d7-bcab-5ef6a5e82934%25default_profile.png'),(225,240,'박코난','같이 집필하실 분들 찾습니다','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/dc8f8ed1-1b06-4c89-89c6-3bb28275eb50%25%EC%BD%94%EB%82%9C.jpg'),(226,241,'익명의 작가_6d2dd8ef-bae5-ae79-b8ca-afc243a008eb','','https://storyboat-profile.s3.ap-northeast-2.amazonaws.com/d29fe1e6-310c-48fd-9ac5-6d0737889115%25default_profile.png');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_tag`
--

DROP TABLE IF EXISTS `profile_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_tag` (
  `profile_tag_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`profile_tag_id`),
  KEY `FK_profile_TO_profile_tag_1` (`profile_id`),
  KEY `FK_tag_TO_profile_tag_1` (`tag_id`),
  CONSTRAINT `FK_profile_TO_profile_tag_1` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`profile_id`),
  CONSTRAINT `FK_tag_TO_profile_tag_1` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=437 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_tag`
--

LOCK TABLES `profile_tag` WRITE;
/*!40000 ALTER TABLE `profile_tag` DISABLE KEYS */;
INSERT INTO `profile_tag` VALUES (392,212,5),(393,212,12),(394,212,9),(395,212,15),(396,212,11),(400,218,6),(401,218,3),(402,218,17),(409,216,21),(410,216,9),(411,216,16),(412,216,22),(413,216,27),(414,216,28),(418,220,7),(419,220,13),(420,220,17),(426,223,11),(427,223,14),(428,223,10),(429,223,13),(430,223,9),(432,222,7),(435,225,12),(436,225,8);
/*!40000 ALTER TABLE `profile_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_token`
--

DROP TABLE IF EXISTS `refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_token` (
  `refresh_token_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `token` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`refresh_token_id`),
  KEY `fk_user_id` (`user_id`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2021 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_token`
--

LOCK TABLES `refresh_token` WRITE;
/*!40000 ALTER TABLE `refresh_token` DISABLE KEYS */;
INSERT INTO `refresh_token` VALUES (1964,227,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IktpWlJqSTVCTDhmdVQ2R1c0bGVKVnoySng3N1E4SVlrdDFtVks5c0NFcDggbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk2MDk3LCJleHAiOjE3MjQzMDA4OTd9.lnzJKzFIwYAitJB6KWBlJFb1GED5XNq_rQsgwJRwC4Y'),(1965,228,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6InZrUUdNM20yNzZLMWtzTkRpRzlOZlY5ZGpDRm9mNFJfRXZsa21NZ2dma2MgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk2MTc2LCJleHAiOjE3MjQzMDA5NzZ9.ItX3DTEliFVz1uXwZFdtiIp260qJisIueZliWPLHIR0'),(1966,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk2NTE2LCJleHAiOjE3MjQzMDEzMTZ9.z8ODLojYDv3Gv5hd1R5NqnfXia8kyyJWD4fZZ-sDUBw'),(1967,228,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6InZrUUdNM20yNzZLMWtzTkRpRzlOZlY5ZGpDRm9mNFJfRXZsa21NZ2dma2MgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk2ODYzLCJleHAiOjE3MjQzMDE2NjN9.jmkiYNBAX7fX8z1IyieFC-A0eXkSDH7sRaAcAlrXYcE'),(1968,228,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6InZrUUdNM20yNzZLMWtzTkRpRzlOZlY5ZGpDRm9mNFJfRXZsa21NZ2dma2MgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk3MDEyLCJleHAiOjE3MjQzMDE4MTJ9.UGHf_CilvvyFtZX4UKhyBx78cClF9TxhjxsoR4eKrpo'),(1969,230,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjM2NDYyMDA5MTIga2FrYW8iLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk3MjUwLCJleHAiOjE3MjQzMDIwNTB9.mDqRdieXWvMgpQKc8wRf_irJxRLUvJ7YH1bITbqLVDU'),(1971,231,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExNTQzMzI3NTQyNjI0NzgxMTMwNyBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk3NjgzLCJleHAiOjE3MjQzMDI0ODN9.7MKo55rg8x4AxibvASv32vnD63jNwbrql28YJV3MXBs'),(1972,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk3Nzk1LCJleHAiOjE3MjQzMDI1OTV9.YeG7aCqrjs0dyoPrqco6T64FfUpKg0Vw2_tOmv45x50'),(1973,232,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjEwMTQ0MDI0NTMwNDUxNTQ3NzQyMCBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk3OTM3LCJleHAiOjE3MjQzMDI3Mzd9.tVTGvSOc-64IQRYCp_Ex1BsyNl0B7VGq1ytGVeV4Rbk'),(1975,228,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6InZrUUdNM20yNzZLMWtzTkRpRzlOZlY5ZGpDRm9mNFJfRXZsa21NZ2dma2MgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk4Mjg4LCJleHAiOjE3MjQzMDMwODh9.76snuO6Wxtpowk8Rw02AQ3ZkPOvaVexfZQC3tHsv4hg'),(1976,228,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6InZrUUdNM20yNzZLMWtzTkRpRzlOZlY5ZGpDRm9mNFJfRXZsa21NZ2dma2MgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk4NTEyLCJleHAiOjE3MjQzMDMzMTJ9._wCGfqxSzzL2oyB_al1-hgEWX8_q14C7cfEU2KfQT80'),(1977,228,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6InZrUUdNM20yNzZLMWtzTkRpRzlOZlY5ZGpDRm9mNFJfRXZsa21NZ2dma2MgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNjk5MDMzLCJleHAiOjE3MjQzMDM4MzN9.IZZLgjVOdu4Yw_Hc7z3vrciMrj4X4hFBTmEHY_zkXhY'),(1978,228,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6InZrUUdNM20yNzZLMWtzTkRpRzlOZlY5ZGpDRm9mNFJfRXZsa21NZ2dma2MgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzAwOTIyLCJleHAiOjE3MjQzMDU3MjJ9.8xy4-i5nquhFHREJlKl8_ZKFAxBfU3VjPXnovdlEzJQ'),(1979,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzAwOTYzLCJleHAiOjE3MjQzMDU3NjN9.O4h7IpQ5mYs2h0yoNdYf1J-RbGELtC40XFACYYMWOJ0'),(1980,234,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjM2NTMyMzg4MTkga2FrYW8iLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzAzMzc4LCJleHAiOjE3MjQzMDgxNzh9.NZEgfSwAdywqAOTUrfEiOnXXY2toTxv_9zuz6incTmU'),(1981,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA0MTM4LCJleHAiOjE3MjQzMDg5Mzh9.j7OXr-jGAQXoNbT-j015SxdEWABZRL23i5Hpgexs6YY'),(1982,235,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjEwMzk3MDcxODYwNjE3NjEzNDAyMiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA0MjA2LCJleHAiOjE3MjQzMDkwMDZ9.-_zp4_WsOhWW5cug3dY54KinibAgD9MCcMzOxqizcVg'),(1983,231,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExNTQzMzI3NTQyNjI0NzgxMTMwNyBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA0MjQ4LCJleHAiOjE3MjQzMDkwNDh9.VA4bfhjq9ei1Jmhf0KmCBGK1tVxn7qK6qEpiBYas7gY'),(1987,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA0NDU4LCJleHAiOjE3MjQzMDkyNTh9.XNoZ3xO7SAx3T3w5UOtxYV4sg3F8pwtK2yxcs1B1MXA'),(1988,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA1MzEzLCJleHAiOjE3MjQzMTAxMTN9.MZYBIq5RaOTWUDbGmHnLM2Y_viNcnveJEPy1hLOi9t8'),(1990,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA2NjgyLCJleHAiOjE3MjQzMTE0ODJ9.JUA5Y9j5vRpBVZdw-qo9Ng16PNamUQjapjjujxyiaQw'),(1991,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA3MzE2LCJleHAiOjE3MjQzMTIxMTZ9.ExX8CfjO5FVZwX8hycILoIdzEYbQzh-DEif_YvhE7XI'),(1992,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA4MzIwLCJleHAiOjE3MjQzMTMxMjB9.-eArtAO7pR1Ex_y1HZMr1poPdE-JuJa4LTDwF70CH1A'),(1993,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA4MzY0LCJleHAiOjE3MjQzMTMxNjR9.UYNxveERG6HI7bwxI-nAUr8afNvD6fJDJUZ7Wbj9MX4'),(1994,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA4NDM5LCJleHAiOjE3MjQzMTMyMzl9.xE4aTdbZ3G4Mp2P_4v_IoeqxIDrkTCuCGBcUIdY6e-U'),(1995,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA4NjQ4LCJleHAiOjE3MjQzMTM0NDh9.1a9PVqXpSWy5C4Ye90-6YM3mmKgT1ttXX7PS_CzGmvo'),(1996,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA4NzU3LCJleHAiOjE3MjQzMTM1NTd9.gsAvMlSPGZkwEgbyGrL0RgRkNR_cfZIdTIEdc-pS3lE'),(1997,237,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjM2NjM2MTEwMzYga2FrYW8iLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA4ODU5LCJleHAiOjE3MjQzMTM2NTl9.J3yPvnXu0WOBTPFxb2H_rEgMqaDWLLvF3WFcV2XyRVM'),(1998,238,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExMzM0NDY2MzM1MjI2Njc5NDMzMSBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA5MTUyLCJleHAiOjE3MjQzMTM5NTJ9.FHuXsCv3kunfetsqtGfJp0jqMAMJ1meUYTv9mss0Bpk'),(2000,231,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExNTQzMzI3NTQyNjI0NzgxMTMwNyBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA5Mzk3LCJleHAiOjE3MjQzMTQxOTd9.noQr90xl4-PYP5s-V235W-jzBuU5PbFRiFlDCof1s28'),(2001,234,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjM2NTMyMzg4MTkga2FrYW8iLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzA5OTQ5LCJleHAiOjE3MjQzMTQ3NDl9.1G_ncAsmKxoRNgCgAnU71VvwLaCtO8MXTiMld8bIWMc'),(2002,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzExMDU1LCJleHAiOjE3MjQzMTU4NTV9.VmLMR-t85Lhw-KQCV8JWk3PUwbR4TDQhSGtKzvn3q7U'),(2003,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzExNTk0LCJleHAiOjE3MjQzMTYzOTR9.S4-06SHG_Oz7rfx4GQtPTxzkDITf5Fwiam4Da01Qm-w'),(2004,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzExNjkzLCJleHAiOjE3MjQzMTY0OTN9.Z9012PSAnJuONmV-WcBoggvcJWqQIiDjM_gRho2XfF8'),(2005,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzEyMjc5LCJleHAiOjE3MjQzMTcwNzl9.79k_fg73l-uT2Zd-pxd1qYsMu9tmLhybFNKPm3wWSzw'),(2006,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzEyODgyLCJleHAiOjE3MjQzMTc2ODJ9._Wlhd8gnb5VzAXjQ9Jq38JIMIXJbQaEdWqy49OEV0as'),(2007,239,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjM2NjU1OTQyMTcga2FrYW8iLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzEzODgxLCJleHAiOjE3MjQzMTg2ODF9.nJeBd_IgTcusbXkSBw5EwzY7zcHwRFpmlevyreAWj8g'),(2008,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzIwNDgwLCJleHAiOjE3MjQzMjUyODB9.ipAgYsLgjU8Wf1a1WYOjvuqTYhIw71WWCww4ir1dMz8'),(2009,229,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IlRBMjlzSFdFQnRiRGZ4dFNPRlNmYUhfdzkxUFJSN3lRdTJfQ3pWUGhnZWMgbmF2ZXIiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzIxMzMyLCJleHAiOjE3MjQzMjYxMzJ9.EZgyzUwnCQ6KvqxxpU5zFCSxu3GLqxUgl15iG6aTKaQ'),(2010,231,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExNTQzMzI3NTQyNjI0NzgxMTMwNyBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzIxNzc5LCJleHAiOjE3MjQzMjY1Nzl9.cKxnf52LCYPmq2dbzEfrC1VFvgNFH09qPOaWoKLpoRw'),(2015,232,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjEwMTQ0MDI0NTMwNDUxNTQ3NzQyMCBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzMwNDY5LCJleHAiOjE3MjQzMzUyNjl9.qsKxiHe3cLAPTCgJmA_iaqY9i3MP_yu5R3RwmLOcMuc'),(2016,232,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjEwMTQ0MDI0NTMwNDUxNTQ3NzQyMCBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzMwNDc4LCJleHAiOjE3MjQzMzUyNzh9.HARbBUA4eWhKEJArWpE2_TDRdzMIVAVj8Z6E7hjsYvU'),(2018,240,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjM2NTM0NDY5NzMga2FrYW8iLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzM0MTg3LCJleHAiOjE3MjQzMzg5ODd9.8ctpPXyrVImsiq1HyN7A1YzPso9IKkuuptHWkyeZmI0'),(2019,241,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExNzk1OTU2NzE1NDU1MDM4NjAzMyBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzM1MjAxLCJleHAiOjE3MjQzNDAwMDF9._I51WSuySpE0MI1gkSOMu6EJDxsSMcQqtHda3fU6YYo'),(2020,233,'eyJhbGciOiJIUzI1NiJ9.eyJjYXRlZ29yeSI6InJlZnJlc2giLCJ1c2VybmFtZSI6IjExODM1NjIyNTA4NDczOTk3MTU4MiBnb29nbGUiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzIzNzM2MDMwLCJleHAiOjE3MjQzNDA4MzB9.YSfj2SCYNM41FaKsFnKB8ttD4Ep6JRxuR56btg3iOX4');
/*!40000 ALTER TABLE `refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studio`
--

DROP TABLE IF EXISTS `studio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `studio` (
  `studio_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` text COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`studio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=283 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studio`
--

LOCK TABLES `studio` WRITE;
/*!40000 ALTER TABLE `studio` DISABLE KEYS */;
INSERT INTO `studio` VALUES (250,'private','private'),(251,'private','private'),(252,'112','122'),(253,'private','private'),(254,'추리소설','추리소설 작성 스튜디오'),(255,'113','222'),(256,'private','private'),(257,'private','private'),(258,'private','private'),(259,'private','private'),(260,'판타지 소설 ?‍♀️','요정과 함께 떠나는 비밀의 숲 '),(261,'유명한 탐정 사무소 ','미스터리 소설 집필 공간 입니다'),(262,'SF 스튜디오','SF를 위한 스튜디오'),(263,'ㅁㄴㅇㄹ','ㅁㄴㅇㄹ'),(264,'ㅂㅈㄷ','ㅂㅈㄷ'),(265,'ㅋ','ㅋ'),(266,'ㅍㅂㅈ','ㅍㅈ'),(267,'123','123'),(268,'private','private'),(269,'스튜디오','스튜디오'),(270,'private','private'),(271,'오늘 스튜디오','오늘의 스튜디오를 만나봐요'),(272,'private','private'),(273,'private','private'),(274,'private','private'),(275,'1','1'),(276,'private','private'),(277,'무서운게 딱 좋아','공포보단 미스테리를 좋아합니다'),(278,'asdf','asdf'),(279,'SSAFY','ssafy'),(280,'private','private'),(281,'추리소설 스튜디오','같이 집필하실분!!!!'),(282,'private','private');
/*!40000 ALTER TABLE `studio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studio_character`
--

DROP TABLE IF EXISTS `studio_character`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `studio_character` (
  `studio_character_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studio_id` int(10) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` text COLLATE utf8mb4_bin DEFAULT NULL,
  `image_url` varchar(2083) COLLATE utf8mb4_bin DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`studio_character_id`),
  KEY `FK_STUDIO_CHARACTER` (`studio_id`),
  CONSTRAINT `FK_STUDIO_CHARACTER` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_studio_TO_studio_character_1` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=329 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studio_character`
--

LOCK TABLES `studio_character` WRITE;
/*!40000 ALTER TABLE `studio_character` DISABLE KEYS */;
INSERT INTO `studio_character` VALUES (273,250,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(274,251,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다. ','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(275,250,'김싸피','개발자 ','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/4742c3e1-1d4c-431b-b174-7e1536a2bd1f%25%EA%B9%80%EC%8B%B8%ED%94%BC%20%20%20%20%20%20%EC%B9%B4%ED%8E%98%EC%97%90%EC%84%9C%20%EB%B0%A4%20%EB%8A%A6%EA%B2%8C%EA%B9%8C%EC%A7%80%20%EC%BD%94%EB%94%A9%EC%9D%84%20%ED%95%98%EA%B3%A0%EC%9E%88%EB%8A%94%20%EA%B0%9C%EB%B0%9C%EC%9E%90%20%EA%B9%80%EC%8B%B8%ED%94%BC_.jpg','성실, 개발'),(276,252,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(277,253,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(278,254,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(279,255,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(281,256,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(282,257,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(283,252,'김싸피','개발자 ','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/4742c3e1-1d4c-431b-b174-7e1536a2bd1f%25%EA%B9%80%EC%8B%B8%ED%94%BC%20%20%20%20%20%20%EC%B9%B4%ED%8E%98%EC%97%90%EC%84%9C%20%EB%B0%A4%20%EB%8A%A6%EA%B2%8C%EA%B9%8C%EC%A7%80%20%EC%BD%94%EB%94%A9%EC%9D%84%20%ED%95%98%EA%B3%A0%EC%9E%88%EB%8A%94%20%EA%B0%9C%EB%B0%9C%EC%9E%90%20%EA%B9%80%EC%8B%B8%ED%94%BC_.jpg','성실, 개발'),(284,258,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(286,260,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(288,262,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(289,260,'코난','멋쟁이 코난','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/42829a21-e7c0-450f-b656-19a438a2136c%25Cap%202024-07-02%2011-18-06-309.png','귀여운, 상냥한'),(290,263,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(291,264,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(292,265,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(293,266,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(294,267,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(295,251,'리나','조선시대의 한옥에 사는 소녀 리나는 자연과 전통을 사랑하는 따뜻한 마음을 가진 인물입니다. 그녀는 한복을 곱게 차려입고, 바람에 흔들리는 대나무를 보며 소소한 행복을 느낍니다. 매일 아침, 그녀는 조용한 정원에서 꽃과 나무를 돌보고, 가끔은 할머니와 함께 한옥의 소소한 이야기를 나누곤 합니다. 리나는 호기심이 많고, 장래에 훌륭한 예술가가 되기를 꿈꾸며, 그림을 그리거나 전통 음악을 배우는 것을 좋아합니다. 그녀의 순수함과 꾸준함은 주변 사람들에게 감동을 주며, 조용한 한옥 안에서 조선시대의 아름다움을 더욱 빛나게 합니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/755a67b1-5338-48a2-b87e-5c9e34f584dd%25img2.jpg','한복, 전통, 자연'),(296,251,'엘레나','전설적인 마법사 엘레나는 갈색 머리카락과 깊은 지혜를 지닌 인디언 소녀입니다. 그녀의 마법은 자연과 깊은 연관이 있으며, 숲의 정령들과 소통하는 능력을 가지고 있습니다. 엘레나는 어린 시절부터 원주율의 기운을 느끼며 마법의 세계에 눈을 떴고, 자연의 균형을 맞추는 일에 평생을 바쳤습니다. 그녀의 마법은 장미와 같은 아름다움과, 호랑이처럼 강력한 힘을 동시에 지니고 있습니다. 엘레나는 원주율의 신비로운 지식과 전통적인 마법 의식을 통해 세계를 지키는 데 헌신하며, 주변의 자연과 조화를 이루는 삶을 살고 있습니다. 그녀의 전설은 세대를 넘어 전해지며, 엘레나의 지혜와 마법은 많은 이들에게 영감을 주고 있습니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/e978ec8a-603e-4bc2-97ce-5564964c31a2%25img3.jpg','마법, 자연, 전통'),(297,251,'하루','하루는 고글을 쓴 검은 머리의 일본인 소년으로, 탐험을 향한 열정이 가득한 인물입니다. 그는 모험을 통해 미지의 세계를 탐색하고, 숨겨진 보물과 신비로운 장소를 발견하는 것을 좋아합니다. 매일 새로운 지도와 장비를 준비하며, 커다란 꿈을 실현하기 위해 끊임없이 도전합니다. 하루는 호기심과 용기로 가득 차 있으며, 어려움에 직면해도 굴하지 않고, 항상 긍정적인 자세로 문제를 해결합니다. 그의 친구들은 그의 용기와 지혜에 감탄하며, 함께 모험을 떠나는 것을 즐깁니다. 하루의 탐험은 매번 새로운 이야기를 만들어내며, 그의 모험은 주변 사람들에게 꿈과 희망을 주고 있습니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/d71032b4-34c7-440a-8ac9-546919353d60%25img4.jpg','탐험, 용기, 호기심'),(298,251,'실비아','실비아는 갈색 눈동자를 가진 10대 영국 소녀로, 언제나 미소를 머금고 있는 밝은 성격을 지니고 있습니다. 그녀의 상징인 연보라색 모자는 그녀의 개성과 개방적인 성격을 잘 나타내며, 그 색깔은 그녀의 상상력과 창의력을 상징합니다. 실비아는 영화에 대한 깊은 사랑을 가지고 있으며, 다양한 장르의 영화를 감상하는 것을 즐깁니다. 특히, 영화 속 캐릭터와 이야기에 몰입하며, 친구들과 함께 영화 밤을 열거나 자신의 영화 리뷰를 쓰는 취미가 있습니다. 그녀는 영화가 사람들에게 주는 감동과 영감을 믿으며, 언젠가는 자신도 훌륭한 영화 감독이 되어 사람들에게 감동적인 이야기를 전달하고 싶어 합니다. 실비아의 긍정적인 에너지와 영화에 대한 열정은 주변 사람들에게도 큰 영향을 미치고 있습니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/19db4939-2979-435b-a33d-309d326c2f74%25img5.jpg','영화, 상상력, 창의력'),(299,251,'마리아','마리아는 파란색 머리와 파란 눈동자를 가진 매력적인 소녀로, 바닷가에서 살며 그곳의 아름다움을 만끽합니다. 그녀는 바다의 청명한 색깔과 자연의 소리를 사랑하며, 매일 해변을 산책하고 조개를 주우며 시간을 보냅니다. 여행에 대한 열정이 가득한 마리아는 새로운 장소를 탐험하고 다양한 문화와 사람들을 만나는 것을 즐깁니다. 그녀는 여행 중에 찍은 사진과 수집한 기념품을 정리하며, 그곳에서의 특별한 순간들을 기록합니다. 마리아는 항상 호기심과 모험심을 가지고 있으며, 자신의 경험을 통해 주변 사람들에게 영감을 주는 이야기꾼이기도 합니다. 그녀의 밝고 활기찬 성격은 언제나 주위의 분위기를 즐겁게 만들며, 바다와 여행에 대한 사랑은 그녀의 삶을 더욱 풍요롭게 합니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/536e6a7c-d7fc-40c6-aac0-8be287e1fb6c%25img6.jpg','여행, 바다, 호기심'),(300,251,'브라운','브라운은 명랑한 성격을 지니고 있으며, 언제나 주위의 사람들과 동물들에게 긍정적인 에너지를 전합니다. 그는 공원에서 뛰어노는 것을 좋아하며, 산책 중에 새로운 친구들을 사귀는 것을 즐깁니다. 브라운의 명랑한 성격과 매력적인 패션은 많은 이들을 기쁘게 하고, 그의 존재 자체가 주변에 행복과 웃음을 가져다줍니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/2c1c3ebb-c84e-43c1-b7f1-7fd8cedcd229%25img7.jpg','긍정, 친구, 행복'),(301,251,'제이콥','제이콥은 최신 기술과 혁신에 능한 미국 출신의 고등학생 엔지니어입니다. 그는 어려서부터 기계와 전자기기에 대한 깊은 관심을 가지고 있었으며, 창의적이고 실용적인 발명 아이디어로 주변의 주목을 받고 있습니다. 제이콥은 자신의 방을 작은 실험실처럼 활용하며, 로봇, 전자 장치, 그리고 다양한 기계 장비를 만드는 데 열정을 쏟습니다. 그의 발명품은 종종 학교의 과학 박람회나 지역 대회에서 주목받고, 실용성과 독창성으로 많은 찬사를 받습니다. 제이콥은 문제 해결에 뛰어난 능력을 가지고 있으며, 기술적 도전을 즐기고 새로운 아이디어를 실현하기 위해 끊임없이 노력합니다. 미래에는 첨단 기술 분야에서 혁신적인 발명가로서 큰 성과를 이루기를 꿈꾸며, 그의 열정과 재능은 동료들에게도 큰 영감을 주고 있습니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/d16ea457-df51-4f7c-8ca6-7ca0939e43fc%25img8.jpg','기술, 발명, 창의성'),(302,268,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(303,269,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(304,259,'코난','내이름은 코난 탐정이죠','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/f802b337-55bd-470f-a12a-4721eaab88dd%25%EC%BD%94%EB%82%9C.png','탐정, 주인공, 천재'),(305,259,'유명한','세계적인 탐정, 하지만 항상 코난이 문제를 해결해 준다','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/e8d44831-a35b-425b-a626-9a8c9c104c5c%25%EC%9C%A0%EB%AA%85%ED%95%9C.jpg','탐정, 어리숙함'),(306,259,'미란이','여자 주인공, 유명한의 딸','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/9bccfff2-7063-44f6-8feb-14db4e2e1ece%25%EB%AF%B8%EB%9E%80%EC%9D%B4.jpg','여주'),(307,261,'코난','내이름은 코난 탐정이죠','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/f802b337-55bd-470f-a12a-4721eaab88dd%25%EC%BD%94%EB%82%9C.png','탐정, 주인공, 천재'),(308,261,'유명한','세계적인 탐정, 하지만 항상 코난이 문제를 해결해 준다','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/e8d44831-a35b-425b-a626-9a8c9c104c5c%25%EC%9C%A0%EB%AA%85%ED%95%9C.jpg','탐정, 어리숙함'),(309,261,'미란이','여자 주인공, 유명한의 딸','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/9bccfff2-7063-44f6-8feb-14db4e2e1ece%25%EB%AF%B8%EB%9E%80%EC%9D%B4.jpg','여주'),(310,270,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(311,271,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(312,272,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(313,273,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(314,273,'젠킨스','화가 많고 나이 많은 할아버지','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/7d250451-8ef9-4e14-85c3-587f937597ad%25angry_jenkins.png','화가많은, 까칠한, 나이든'),(315,274,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(316,275,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(317,276,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(318,277,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(319,273,'할머니','언제나 친절한 할머니','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/768d59fe-77e0-4c6d-bbe6-551b550fd5d4%25%EC%A0%A0%ED%82%A8%EC%8A%A4%20%ED%95%A0%EB%A8%B8%EB%8B%88%20%20%20%20%20%20%EA%B7%B8%EB%85%80%EB%8A%94%20%EC%96%B8%EC%A0%9C%EB%82%98%20%EC%9B%83%EC%9C%BC%EB%A9%B0%20%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%84%20%EB%8C%80%ED%95%98%EB%A9%B0%20%EC%B9%9C%EC%A0%88%EC%9D%84%20%EB%B0%B0%ED%91%BC%EB%8B%A4_%EA%B7%B8%EB%85%80%EC%9D%98%20%EB%A8%B8%EB%A6%AC%EB%8A%94%20%EB%B0%B1%EB%B0%9C%EC%9D%B4%EB%8B%A4_.jfif','귀여운, 상냥한'),(320,278,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(321,277,'젠킨스','화가 많고 나이 많은 할아버지','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/7d250451-8ef9-4e14-85c3-587f937597ad%25angry_jenkins.png','화가많은, 까칠한, 나이든'),(322,279,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(323,270,'보람','반장임','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/354068af-6cde-430c-bdff-9ccfbe89fce8%25logo.png','귀여운, 상냥한'),(324,280,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(325,280,'김싸피','개발자','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/1136ca2d-ac4c-462e-a794-0fc99eef6f4d%25%EA%B9%80%EC%8B%B8%ED%94%BC%20%20%20%20%20%20%ED%95%AD%EC%83%81%20%EB%B0%A4%EB%8A%A6%EA%B2%8C%20%EC%BD%94%EB%94%A9%EC%9D%84%20%ED%95%98%EB%8A%94%20%EA%B9%80%EC%8B%B8%ED%94%BC_.jfif','귀여운, 상냥한, 개발자'),(326,281,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악'),(327,261,'김싸피','개발자','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/1136ca2d-ac4c-462e-a794-0fc99eef6f4d%25%EA%B9%80%EC%8B%B8%ED%94%BC%20%20%20%20%20%20%ED%95%AD%EC%83%81%20%EB%B0%A4%EB%8A%A6%EA%B2%8C%20%EC%BD%94%EB%94%A9%EC%9D%84%20%ED%95%98%EB%8A%94%20%EA%B9%80%EC%8B%B8%ED%94%BC_.jfif','귀여운, 상냥한, 개발자'),(328,282,'히카리','히카리는 순수한 마음을 가진 초등학생으로, 피아노 연주를 사랑하는 소녀입니다. 음악에 대한 깊은 애정과 천부적인 재능을 가지고 있습니다. 그녀는 연주로 사람들의 마음을 감동시킵니다. 성격은 밝고 친절하며, 친구들과의 관계를 소중히 여기고 있습니다. 히카리는 매일 연습을 통해 더욱 뛰어난 피아니스트가 되기를 꿈꾸며, 그녀의 음악은 듣는 이들에게 평화와 행복을 가져다줍니다. 그녀의 순수함과 열정은 주변 사람들에게 긍정적인 영향을 미칩니다.','https://storyboat-character.s3.ap-northeast-2.amazonaws.com/img1.jpg','피아노, 순수, 음악');
/*!40000 ALTER TABLE `studio_character` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studio_idea`
--

DROP TABLE IF EXISTS `studio_idea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `studio_idea` (
  `studio_idea_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studio_id` int(10) unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `content` text COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`studio_idea_id`),
  KEY `FK_STUDIO_IDEA` (`studio_id`),
  CONSTRAINT `FK_STUDIO_IDEA` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_studio_TO_studio_idea_1` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studio_idea`
--

LOCK TABLES `studio_idea` WRITE;
/*!40000 ALTER TABLE `studio_idea` DISABLE KEYS */;
INSERT INTO `studio_idea` VALUES (115,261,'코난의 과거','잘나가던 탐정 남도일이 검은 조직의 약으로 어려짐'),(116,261,'코난의 도구 보급처','브라운 박사의 발명품'),(117,261,'코난의 마취총','손목 시계로 위장되 있으며 대체로 유명한이 맞게됨'),(118,261,'4화 아이디어','해외에서 실종 사건 해결하는 에피소드?'),(119,273,'젠킨스 할아버지','어느날 젠킨스 할아버지가 파업해서 모든 자동화가 멈췄다');
/*!40000 ALTER TABLE `studio_idea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studio_story`
--

DROP TABLE IF EXISTS `studio_story`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `studio_story` (
  `studio_story_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studio_id` int(10) unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`studio_story_id`),
  KEY `FK_STUDIO_STORY` (`studio_id`),
  CONSTRAINT `FK_STUDIO_STORY` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_studio_TO_studio_story_1` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studio_story`
--

LOCK TABLES `studio_story` WRITE;
/*!40000 ALTER TABLE `studio_story` DISABLE KEYS */;
INSERT INTO `studio_story` VALUES (166,252,'ㅌㅌㅌ','2024-08-15 14:00:48'),(167,261,'1화 - 계곡 산장 살인사건','2024-08-15 14:22:04'),(168,261,'2화 - 사라진 시체 사건','2024-08-15 14:26:43'),(169,261,'3화 - 유령저택 살인사건','2024-08-16 00:13:21'),(170,254,'1','2024-08-15 14:53:48'),(171,269,'스토리1','2024-08-15 15:30:32'),(172,270,'아이디어 정리','2024-08-15 15:44:31'),(173,271,'오늘 스토리 작성','2024-08-15 23:04:36'),(174,254,'1','2024-08-15 15:50:34'),(175,275,'1','2024-08-15 18:25:17'),(176,277,'할일','2024-08-15 20:27:30'),(177,270,'아이디어 보관','2024-08-15 20:28:25'),(178,279,'나혼자만레벨업','2024-08-15 21:51:48');
/*!40000 ALTER TABLE `studio_story` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studio_user`
--

DROP TABLE IF EXISTS `studio_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `studio_user` (
  `studio_user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studio_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `reg_date` datetime DEFAULT NULL,
  PRIMARY KEY (`studio_user_id`),
  KEY `FK_user_TO_studio_user_1` (`user_id`),
  KEY `FK_STUDIO_USER` (`studio_id`),
  CONSTRAINT `FK_STUDIO_USER` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_studio_TO_studio_user_1` FOREIGN KEY (`studio_id`) REFERENCES `studio` (`studio_id`),
  CONSTRAINT `FK_user_TO_studio_user_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=290 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studio_user`
--

LOCK TABLES `studio_user` WRITE;
/*!40000 ALTER TABLE `studio_user` DISABLE KEYS */;
INSERT INTO `studio_user` VALUES (248,250,227,'ROLE_PRIVATE','2024-08-15 13:28:17'),(249,251,228,'ROLE_PRIVATE','2024-08-15 13:29:36'),(250,252,227,'ROLE_OWNER','2024-08-15 13:31:45'),(251,253,229,'ROLE_PRIVATE','2024-08-15 13:35:16'),(252,254,229,'ROLE_OWNER','2024-08-15 13:35:41'),(253,255,227,'ROLE_OWNER','2024-08-15 13:41:14'),(254,256,230,'ROLE_PRIVATE','2024-08-15 13:47:30'),(255,257,231,'ROLE_PRIVATE','2024-08-15 13:54:43'),(256,258,232,'ROLE_PRIVATE','2024-08-15 13:58:57'),(257,259,233,'ROLE_PRIVATE','2024-08-15 14:04:00'),(258,260,228,'ROLE_OWNER','2024-08-15 14:05:23'),(259,261,233,'ROLE_OWNER','2024-08-15 14:08:13'),(260,262,231,'ROLE_OWNER','2024-08-15 14:09:04'),(261,263,231,'ROLE_OWNER','2024-08-15 14:12:23'),(262,264,231,'ROLE_OWNER','2024-08-15 14:13:31'),(263,265,231,'ROLE_OWNER','2024-08-15 14:14:09'),(264,266,231,'ROLE_OWNER','2024-08-15 14:15:12'),(265,267,231,'ROLE_OWNER','2024-08-15 14:16:10'),(266,261,231,'ROLE_MEMBER','2024-08-15 14:21:28'),(267,268,234,'ROLE_PRIVATE','2024-08-15 15:29:38'),(268,269,234,'ROLE_OWNER','2024-08-15 15:30:00'),(269,270,235,'ROLE_PRIVATE','2024-08-15 15:43:26'),(270,271,235,'ROLE_OWNER','2024-08-15 15:44:19'),(271,252,235,'ROLE_REQUESTER','2024-08-15 15:45:48'),(272,263,235,'ROLE_REQUESTER','2024-08-15 15:46:07'),(273,261,235,'ROLE_MEMBER','2024-08-15 15:46:51'),(274,272,236,'ROLE_PRIVATE','2024-08-15 15:47:30'),(275,261,229,'ROLE_MEMBER','2024-08-15 15:53:45'),(276,273,237,'ROLE_PRIVATE','2024-08-15 17:00:59'),(277,274,238,'ROLE_PRIVATE','2024-08-15 17:05:52'),(278,275,229,'ROLE_OWNER','2024-08-15 17:10:07'),(279,276,239,'ROLE_PRIVATE','2024-08-15 18:24:41'),(280,275,239,'ROLE_MEMBER','2024-08-15 18:24:56'),(281,277,237,'ROLE_OWNER','2024-08-15 19:01:49'),(282,278,231,'ROLE_OWNER','2024-08-15 20:22:08'),(283,262,237,'ROLE_REQUESTER','2024-08-15 20:27:00'),(284,279,238,'ROLE_OWNER','2024-08-15 21:43:26'),(285,280,240,'ROLE_PRIVATE','2024-08-16 00:03:07'),(286,281,240,'ROLE_OWNER','2024-08-16 00:07:03'),(287,281,233,'ROLE_VIEWER','2024-08-16 00:07:42'),(288,261,240,'ROLE_MEMBER','2024-08-16 00:09:51'),(289,282,241,'ROLE_PRIVATE','2024-08-16 00:20:01');
/*!40000 ALTER TABLE `studio_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `tag_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (2,'소설','#FF5733'),(3,'현대소설','#C70039'),(4,'고전소설','#900C3F'),(5,'판타지','#FFC300'),(6,'SF (과학소설)','#DAF7A6'),(7,'미스터리','#5C4033'),(8,'스릴러','#C70039'),(9,'로맨스','#FF69B4'),(10,'역사소설','#D2691E'),(11,'문학','#FF4500'),(12,'추리','#4682B4'),(13,'공포','#333333'),(14,'드라마','#FF4500'),(15,'모험','#FFD700'),(16,'청소년소설','#7CFC00'),(17,'성장소설','#00FA9A'),(18,'범죄','#8B0000'),(19,'코미디','#FFFF00'),(20,'서스펜스','#800000'),(21,'가족','#FF6347'),(22,'자기계발','#2E8B57'),(23,'사회적','#4682B4'),(24,'철학적','#808080'),(25,'시가','#FF4500'),(26,'실험문학','#8A2BE2'),(27,'에세이','#FF6347'),(28,'로맨스판타지','#FFB6C1'),(29,'전쟁소설','#A52A2A'),(30,'여행소설','#20B2AA'),(31,'가상현실','#00CED1');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `provider` varchar(16) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(254) COLLATE utf8mb4_bin DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (227,'KiZRjI5BL8fuT6GW4leJVz2Jx77Q8IYkt1mVK9sCEp8','naver','dlwndgus5@naver.com',0),(228,'vkQGM3m276K1ksNDiG9NfV9djCFof4R_EvlkmMggfkc','naver','bayleaf07@naver.com',0),(229,'TA29sHWEBtbDfxtSOFSfaH_w91PRR7yQu2_CzVPhgec','naver','yj009977@hanmail.net',0),(230,'3646200912','kakao','dlwndgus5@naver.com',0),(231,'115433275426247811307','google','siokim001@gmail.com',0),(232,'101440245304515477420','google','shb204@gmail.com',0),(233,'118356225084739971582','google','doublehyun98@gmail.com',0),(234,'3653238819','kakao','yj009977@hanmail.net',0),(235,'103970718606176134022','google','qhfka961@gmail.com',0),(236,'108713407271682005396','google','dnlwnd24@gmail.com',0),(237,'3663611036','kakao','jeongb9716@kakao.com',0),(238,'113344663352266794331','google','ssafy.coach003@gmail.com',0),(239,'3665594217','kakao','dlawnsdlekd@naver.com',0),(240,'3653446973','kakao','zion0425@naver.com',0),(241,'117959567154550386033','google','ssafykim52@gmail.com',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  0:47:30
